__MODULE__ = "ᴄᴏʟᴏɴɢ"
__HELP__ =  """🛠 **BANTUAN UNTUK MODULE COLONG 」**

〄➠ **ᴘᴇʀɪɴᴛᴀʜ: .colong**
〄➠ **ᴘᴇɴᴊᴇʟᴀsᴀɴ: ᴜɴᴛᴜᴋ ᴍᴇɴɢᴀᴍʙɪʟ ғᴏᴛᴏ 1x ʟɪʜᴀᴛ**"""
